var searchData=
[
  ['num_5fedges',['num_edges',['../classGraph.html#a6102afe11687fd9032bcc8db39b456f7',1,'Graph']]],
  ['num_5fvertices',['num_vertices',['../classGraph.html#a3026148e0089f6cbd8ef8c7cf58c99c5',1,'Graph']]]
];
